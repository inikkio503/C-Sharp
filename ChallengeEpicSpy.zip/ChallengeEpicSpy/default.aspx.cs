﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ChallengeEpicSpy
{
    public partial class _default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                endDateCalendar.SelectedDate = DateTime.Now.Date;
                startDateCalendar.SelectedDate = DateTime.Now.Date.AddDays(14);
                projectedEndCalendar.SelectedDate = DateTime.Now.Date.AddDays(21);
            }
        }
    
        protected void assignButton_Click(object sender, EventArgs e)
        {
                TimeSpan durationOfAssigment = endDateCalendar.SelectedDate.Subtract(startDateCalendar.SelectedDate);
                double totalperdiem = durationOfAssigment.TotalDays * 500.0;

                if (durationOfAssigment.TotalDays > 21)
                {

                    totalperdiem += 1000.00;
                    
                }
                resultLabel.Text = String.Format("Assigment {0} has been assigned to {1}, Budget Total :{2} ",
                assigmentNameTextBox.Text,
                spyNameTextBox.Text,
                totalperdiem);
                
                

                TimeSpan betweenAssignments = startDateCalendar.SelectedDate.Subtract(endDateCalendar.SelectedDate);
                if (betweenAssignments.TotalDays < 14) 
                {
                    resultLabel.Text = "Error: Must be at least 14 days between assigments! Take a nap before starting a new adventure";

                    DateTime newAssigmentEarliest = endDateCalendar.SelectedDate.AddDays(14);

                    startDateCalendar.SelectedDate = newAssigmentEarliest;
                    startDateCalendar.VisibleDate = newAssigmentEarliest;
                }
            }
        }
    }
